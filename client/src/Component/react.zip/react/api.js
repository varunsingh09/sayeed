const HOST_NAME = `http://127.0.0.1:8800/api`
export const LOGIN_API = `${HOST_NAME}/admins/login`
export const STATE_LIST = `${HOST_NAME}/admins/stateList`
export const REGISTRATION_API = `${HOST_NAME}/admins/registration`

